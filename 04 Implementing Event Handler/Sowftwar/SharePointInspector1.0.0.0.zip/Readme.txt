======================================
=== - SharePoint Inspector (SPI) - ===
======================================

Application : SharePoint Inspector (a.k.a. SPI)
Author : Gat, Gaetan Bouveret in "real" life ;)
Email : gat@gatweb.fr
Blog : http://www.gatweb.fr/
SharePoint Inspector Wiki : http://www.gatweb.fr/sharepointinspector/

SharePoint Inspector is a free tool to browse your SharePoint 2007 farm.
When I talk about SharePoint 2007, I mean Windows SharePoint Services v3 (WSS v3) and Microsoft Office SharePoint Server 2007 (MOSS).

Its main purpose is to help SharePoint developer
You can see objects composing its structure, get their properties by reflection, which can be very useful when you want to check if your code does what it should do.
You can use also some advanced features like activate/deactivate SharePoint features, add/remove event receivers, manage your recycle bin.

Feel free to use this program, but please don't redistribute it and don't provide direct link for download purpose.

I don't provide official support for this tool, but you can try to mail me if you get bugs or want new features.


:: HISTORY LOGS

Version 1.0.0.0
	. First version of SharePoint Inspector.
	. You can display these objects :
		. farm
		. servers
		. services
		. features
		. feature definitions
		. solutions
		. web applications
		. site collections
		. sites
		. lists
		. content types
		. site columns
		. content databases
		. event receivers
		. workflow associations
		. recycle bin
	. Available actions :
		. activate / deactivate features
		. add / remove event receivers on list using the Event Receiver picker (the DLL must be in the GAC in order to attach the event)
		. manage recycle bin (restore, move to second stage)